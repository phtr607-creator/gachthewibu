require("dotenv").config();
const express = require("express");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const Database = require("better-sqlite3");
const path = require("path");
const fs = require("fs");

const app = express();
const PORT = Number(process.env.PORT || 3000);
const JWT_SECRET = process.env.JWT_SECRET;
if (!JWT_SECRET || JWT_SECRET.length < 32) {
  console.error("Set JWT_SECRET in .env to a random string of at least 32 characters.");
  process.exit(1);
}
if (process.env.NODE_ENV === "production" && !process.env.CARD_PROVIDER_API_KEY) {
  console.warn("Provider API not configured. Real card submissions will be rejected safely.");
}

app.disable("x-powered-by");
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: "20kb" }));
app.use(express.static(path.join(__dirname, "public")));
app.use("/api/", rateLimit({ windowMs: 60 * 1000, limit: 60, standardHeaders: true, legacyHeaders: false }));

const dataDir = path.join(__dirname, "data");
fs.mkdirSync(dataDir, { recursive: true });
const db = new Database(path.join(dataDir, "gachthewibu.db"));
db.pragma("journal_mode = WAL");
db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  email TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'user',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS transactions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  network TEXT NOT NULL,
  denomination INTEGER NOT NULL,
  serial_enc TEXT NOT NULL,
  pin_enc TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending_provider',
  amount_received INTEGER NOT NULL DEFAULT 0,
  note TEXT NOT NULL DEFAULT 'Chưa kết nối nhà cung cấp API',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(user_id) REFERENCES users(id)
);
`);
const count = db.prepare("SELECT COUNT(*) AS n FROM users WHERE role='admin'").get().n;
if (!count && process.env.ADMIN_EMAIL && process.env.ADMIN_PASSWORD && process.env.ADMIN_PASSWORD !== "replace_this_password") {
  const hash = bcrypt.hashSync(process.env.ADMIN_PASSWORD, 12);
  try { db.prepare("INSERT INTO users(email,password_hash,role) VALUES(?,?, 'admin')").run(process.env.ADMIN_EMAIL.toLowerCase(), hash); }
  catch (e) { console.error("Admin bootstrap failed:", e.message); }
}

function tokenFor(user) {
  return jwt.sign({ id: user.id, role: user.role }, JWT_SECRET, { expiresIn: "12h" });
}
function auth(req, res, next) {
  const raw = req.headers.authorization || "";
  const token = raw.startsWith("Bearer ") ? raw.slice(7) : "";
  try {
    if (!token) throw new Error("missing");
    req.user = jwt.verify(token, JWT_SECRET);
    next();
  } catch { res.status(401).json({ error: "Vui lòng đăng nhập lại." }); }
}
function adminOnly(req, res, next) {
  if (req.user.role !== "admin") return res.status(403).json({ error: "Bạn không có quyền quản trị." });
  next();
}
function validEmail(email) {
  return typeof email === "string" && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) && email.length <= 190;
}

app.post("/api/register", rateLimit({ windowMs: 15 * 60 * 1000, limit: 8 }), async (req, res) => {
  const email = String(req.body.email || "").trim().toLowerCase();
  const password = String(req.body.password || "");
  if (!validEmail(email)) return res.status(400).json({ error: "Email không hợp lệ." });
  if (password.length < 10 || password.length > 128) return res.status(400).json({ error: "Mật khẩu cần từ 10 đến 128 ký tự." });
  const hash = await bcrypt.hash(password, 12);
  try {
    const result = db.prepare("INSERT INTO users(email,password_hash) VALUES(?,?)").run(email, hash);
    const user = { id: Number(result.lastInsertRowid), email, role: "user" };
    res.status(201).json({ token: tokenFor(user), user: { id: user.id, email, role: user.role } });
  } catch (e) {
    if (String(e.message).includes("UNIQUE")) return res.status(409).json({ error: "Email này đã được đăng ký." });
    res.status(500).json({ error: "Không thể tạo tài khoản lúc này." });
  }
});
app.post("/api/login", rateLimit({ windowMs: 15 * 60 * 1000, limit: 10 }), async (req, res) => {
  const email = String(req.body.email || "").trim().toLowerCase();
  const password = String(req.body.password || "");
  const user = db.prepare("SELECT * FROM users WHERE email=?").get(email);
  if (!user || !(await bcrypt.compare(password, user.password_hash))) return res.status(401).json({ error: "Email hoặc mật khẩu không đúng." });
  res.json({ token: tokenFor(user), user: { id: user.id, email: user.email, role: user.role } });
});
app.get("/api/me", auth, (req, res) => {
  const user = db.prepare("SELECT id,email,role,created_at FROM users WHERE id=?").get(req.user.id);
  if (!user) return res.status(401).json({ error: "Tài khoản không tồn tại." });
  res.json({ user });
});
app.get("/api/transactions", auth, (req, res) => {
  const rows = db.prepare("SELECT id,network,denomination,status,amount_received,note,created_at FROM transactions WHERE user_id=? ORDER BY id DESC LIMIT 100").all(req.user.id);
  res.json({ transactions: rows });
});

/*
 * Provider adapter intentionally fails closed. Replace this function only after:
 * 1) signing a contract / getting official API documentation,
 * 2) confirming supported networks, fees, callback signatures and settlement terms,
 * 3) implementing provider signature verification and idempotency.
 * Never return "success" without verified provider confirmation.
 */
async function submitToProvider() {
  if (!process.env.CARD_PROVIDER_BASE_URL || !process.env.CARD_PROVIDER_API_KEY || !process.env.CARD_PROVIDER_API_SECRET) {
    throw new Error("Chưa kết nối nhà cung cấp API. Giao dịch thật chưa được gửi.");
  }
  throw new Error("Adapter nhà cung cấp chưa được triển khai theo tài liệu API chính thức.");
}
app.post("/api/cards", auth, rateLimit({ windowMs: 60 * 1000, limit: 5 }), async (req, res) => {
  const network = String(req.body.network || "");
  const denomination = Number(req.body.denomination);
  const serial = String(req.body.serial || "").trim();
  const pin = String(req.body.pin || "").trim();
  const networks = ["Viettel","MobiFone","VinaPhone","Garena","Zing","Vietnamobile","Vcoin"];
  const denominations = [10000,20000,30000,50000,100000,200000,300000,500000,1000000];
  if (!networks.includes(network) || !denominations.includes(denomination) ||
      serial.length < 6 || serial.length > 80 || pin.length < 6 || pin.length > 100) {
    return res.status(400).json({ error: "Thông tin thẻ không hợp lệ. Vui lòng kiểm tra loại thẻ, mệnh giá, seri và mã thẻ." });
  }
  // Do not store raw card credentials. Until encryption + provider flow are configured,
  // reject the request instead of saving sensitive card data or pretending it was processed.
  try {
    await submitToProvider();
    return res.status(503).json({ error: "Nhà cung cấp chưa sẵn sàng xử lý giao dịch." });
  } catch (e) {
    return res.status(503).json({ error: e.message || "Nhà cung cấp chưa sẵn sàng." });
  }
});
app.get("/api/admin/summary", auth, adminOnly, (req, res) => {
  const users = db.prepare("SELECT COUNT(*) n FROM users").get().n;
  const tx = db.prepare("SELECT COUNT(*) n FROM transactions").get().n;
  res.json({ users, transactions: tx, providerConfigured: Boolean(process.env.CARD_PROVIDER_BASE_URL && process.env.CARD_PROVIDER_API_KEY && process.env.CARD_PROVIDER_API_SECRET) });
});
app.get("*", (req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));
app.listen(PORT, () => console.log(`GachTheWibu running on http://localhost:${PORT}`));
